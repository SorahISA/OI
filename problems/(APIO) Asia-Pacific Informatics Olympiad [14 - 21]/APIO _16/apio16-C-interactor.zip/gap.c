#include "gap.h"

long long findGap(int T, int N)
{
	return 0;
}
