
void MinMax(long long, long long, long long*, long long*);
