#!/bin/sh

./gap < gap.in
