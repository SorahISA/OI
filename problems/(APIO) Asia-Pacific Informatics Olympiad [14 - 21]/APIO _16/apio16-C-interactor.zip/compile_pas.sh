#!/bin/sh

fpc -XS -O2 -ogap grader.pas
