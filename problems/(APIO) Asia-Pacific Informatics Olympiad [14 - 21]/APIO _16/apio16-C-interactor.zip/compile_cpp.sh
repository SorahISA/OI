#!/bin/sh

g++ gap.cpp grader.cpp -o gap -O2 -static -std=c++11
