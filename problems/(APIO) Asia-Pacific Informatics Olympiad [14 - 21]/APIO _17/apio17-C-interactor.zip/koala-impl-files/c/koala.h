#ifndef __KOALA_H
#define __KOALA_H

void playRound(int *B, int *R);

int minValue(int N, int W);
int maxValue(int N, int W);
int greaterValue(int N, int W);
void allValues(int N, int W, int *P);

#endif  // __KOALA_H
