#!/bin/sh

g++ koala.cpp grader.cpp -o koala -O2 -static -std=c++11
