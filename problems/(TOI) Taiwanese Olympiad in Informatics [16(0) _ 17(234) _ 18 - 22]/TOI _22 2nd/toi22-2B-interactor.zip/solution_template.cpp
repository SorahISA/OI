#include <string>
using namespace std;

char GetColor(int x, int y);
int GetRectangle(int x1, int y1, int x2, int y2);

string MaxRedBlueDifference(int n) {
  // n == 5
    int a = GetRectangle(0, 0, 5, 3);
    int b = GetRectangle(3, 3, 5, 5);
    char c = GetColor(4, 5);
    return "UUURRRURUR";
}
