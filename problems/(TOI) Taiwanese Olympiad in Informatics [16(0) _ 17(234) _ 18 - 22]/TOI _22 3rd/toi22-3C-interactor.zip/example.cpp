#include <string>
#include <vector>
#include <algorithm>
#include "hieroglyphs.h"
using namespace std;

long long n;
int q,k,r,d;

string Alice(long long x) {
    if (!n) {
        n = getN();
        q = getQ();
        k = getK();
        r = getR();
        d = getD();
    }

    if (x == 3) {
        return "BBB";
    } else if (x == 5) {
        return "BB";
    }
    return "B";
}

long long Bob(string s) {
    if (s == "BB") {
        return 5;
    } else if (s == "BWB") {
        return 3;
    }
    return 0;
}
