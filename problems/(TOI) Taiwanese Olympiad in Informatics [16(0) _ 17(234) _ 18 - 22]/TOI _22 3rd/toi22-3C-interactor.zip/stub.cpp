/**
This is a simple wrapper for communication with the manager.
DO NOT CHANGE THIS FILE!!!!!
**/

#include <cstdio>
#include <cassert>
#include <cstring>
#include <string>
using namespace std;

// Functions to be implemented in the solution.
string Alice(long long x);
long long Bob(string s);

namespace {
int Q, k, r, d;
long long n;
FILE *fifo_in, *fifo_out;
void run();
}

int getQ() {
    return Q;
}
long long getN() {
    return n;
}
int getK() {
    return k;
}
int getR() {
    return r;
}
int getD() {
    return d;
}

int main(int argc, char **argv) {

    // IF YOU WANT TO TEST LOCALLY ON YOUR COMPUTER,
    // 如果你想要在本地端測試你的程式，
    // COMMENT THESE TWO LINES AND UNCOMMENT THE TWO LINES BELOW.
    // 把下面這兩行註解起來，然後把更下面兩行打開，這樣就可以從命令列互動了。
    fifo_in = fopen(argv[1], "r");
    fifo_out = fopen(argv[2], "w");
    // fifo_in = stdin;
    // fifo_out = stdout;

    run();

    fclose(fifo_in);
    fclose(fifo_out);
    return 0;
}

////////////////////////////////////////////////
namespace {
char role[255];
char s[200005];

int _recv_int() {
    int val;
    int ret = fscanf(fifo_in, "%d", &val);
    // Receives error.
    if (ret != 1) {
        fclose(fifo_in);
        fclose(fifo_out);
        exit(0);
    }
    return val;
}
long long _recv_ll() {
    long long val;
    int ret = fscanf(fifo_in, "%lld", &val);
    // Receives error.
    if (ret != 1) {
        fclose(fifo_in);
        fclose(fifo_out);
        exit(0);
    }
    return val;
}
void _recv_string(char x[]) {
    int ret = fscanf(fifo_in, "%s", x);
    if (ret != 1) {
        fclose(fifo_in);
        fclose(fifo_out);
        exit(0);
    }
}
void _send_string(const string& x) {
    fprintf(fifo_out, "%s\n", x.c_str());
    fflush(fifo_out);
}
void _send_ll(long long x) {
    fprintf(fifo_out, "%lld\n", x);
    fflush(fifo_out);
}

void run() {
    _recv_string(role);
    Q = _recv_int();
    n = _recv_ll();
    k = _recv_int();
    r = _recv_int();
    d = _recv_int();

    if (!strcmp(role, "Alice")) {
        for (int i=0; i<Q; i++) {
            long long x = _recv_ll();
            string s = Alice(x);
            assert(s.length());
            _send_string(s);
        }
    }
    if (!strcmp(role, "Bob")) {
        for (int i=0; i<Q; i++) {
            _recv_string(s);
            _send_ll(Bob(s));
        }
    }
}
}  // namespace
