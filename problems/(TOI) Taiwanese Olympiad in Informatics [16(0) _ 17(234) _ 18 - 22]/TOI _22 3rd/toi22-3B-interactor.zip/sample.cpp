#include <vector>

int PerfectScoreOperationLimit();
void ReplaceByComplement(const std::vector<int>& subset);
std::vector<int> ReachableVertices(int vertex, int distance);
void Reset();

void Login(int n) {
  // 請在這邊撰寫你的程式碼。
}
