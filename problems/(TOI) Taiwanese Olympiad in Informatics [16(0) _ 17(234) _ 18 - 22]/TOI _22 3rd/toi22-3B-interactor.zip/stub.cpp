/**
This is a simple wrapper for communication with the manager.
DO NOT CHANGE THIS FILE!!!!!
**/

#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <set>
#include <string>
#include <vector>
using namespace std;

// Functions to be implemented in the solution.
void Login(int n);

// Functions provided to the solution.
int PerfectScoreOperationLimit();
void ReplaceByComplement(const vector<int>& subset);
vector<int> ReachableVertices(int vertex, int distance);
void Reset();


////////////////////////////////////////////////
namespace {  // Used in this file only.
void run();
FILE *fifo_in, *fifo_out;
void _send_msg(const string& msg);
void _send_msg(const string& msg, const int v, const int d);
void _send_msg(const string& msg, const vector<int>& subset);
vector<int> _recv_list();
int _recv_int();
}  // namespace
////////////////////////////////////////////////

int main(int argc, char **argv) {
    
    // IF YOU WANT TO TEST LOCALLY ON YOUR COMPUTER,
    // 如果你想要在本地端測試你的程式，
    // COMMENT THESE TWO LINES AND UNCOMMENT THE TWO LINES BELOW.
    // 把下面這兩行註解起來，然後把更下面兩行打開，這樣就可以從命令列互動了。
    fifo_in = fopen(argv[1], "r");
    fifo_out = fopen(argv[2], "w");
    // fifo_in = stdin;
    // fifo_out = stdout;

    run();

    fclose(fifo_in);
    fclose(fifo_out);
    return 0;
}

////////////////////////////////////////////////
namespace {
void _send_msg(const string& msg) {
    fprintf(fifo_out, "%s\n", msg.c_str());
    fflush(fifo_out);
}

void _send_msg(const string& msg, const int v, const int d) {
    string query = msg + " " + to_string(v) + " " + to_string(d);
    fprintf(fifo_out, "%s\n", query.c_str());
    fflush(fifo_out);
}

void _send_msg(const string& msg, const vector<int>& subset) {
    string query = msg + " " + to_string(subset.size());
    for (int x : subset) query += " " + to_string(x);
    fprintf(fifo_out, "%s\n", query.c_str());
    fflush(fifo_out);
}

vector<int> _recv_list() {
    vector<int> ret;
    int k = _recv_int();
    ret.resize(k);
    for (int i = 0; i < k; i++) {
        ret[i] = _recv_int();
    }
    return ret;
}

int _recv_int() {
    int val;
    int ret = fscanf(fifo_in, "%d", &val);
    // Receives error.
    if (ret != 1 || val == -1) {
        fclose(fifo_in);
        fclose(fifo_out);
        exit(0);
    }
    return val;
}

void run() {
    int n = _recv_int();
    Login(n);
    _send_msg("done");
}
}  // namespace

int score_limit = 0;
int PerfectScoreOperationLimit() {
    if (!score_limit) {
        _send_msg("get_perfect_score_operation_limit");
        score_limit = _recv_int();
    }
    return score_limit;
}

void ReplaceByComplement(const vector<int>& subset) {
    _send_msg("replace_by_complement", subset);
}

vector<int> ReachableVertices(int vertex, int distance) {
    _send_msg("reachable_vertices", vertex, distance);
    return _recv_list();
}

void Reset() {
    _send_msg("reset");
}
