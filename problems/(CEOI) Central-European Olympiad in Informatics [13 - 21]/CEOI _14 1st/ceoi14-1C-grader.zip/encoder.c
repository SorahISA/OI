int encode (int n, int x, int y) {
  return (x + y) % 2;
}