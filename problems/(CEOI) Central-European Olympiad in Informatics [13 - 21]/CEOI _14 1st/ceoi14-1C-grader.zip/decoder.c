int decode (int n, int q, int h) {
	return (q + h) % 2;
}