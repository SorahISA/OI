int countTreasure (int r1, int c1, int r2, int c2);
void Report (int r, int c);