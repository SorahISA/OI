#include <stdio.h>
#include <stdlib.h>

#define MAXE 20000000
#define HS (3 * MAXE)

static unsigned hash[HS][2];

static int n, m;

static int
find (unsigned x, unsigned y)
{
  unsigned h;
  
  if (x > y)
    {
      h = x;
      x = y;
      y = h;
    }

  h = ((unsigned) n * x + y) % HS;

  while (hash[h][0])
    {
      if (hash[h][0] == x && hash[h][1] == y)
	return 1;

      h++;
      if (h == HS)
	h = 0;
    }

  hash[h][0] = x;
  hash[h][1] = y;

  return 0;
}

int main (int argc, char *argv[])
{
  int i, x, y;
  FILE *fin = fopen (argv[1], "r");

  if (fscanf (fin, "%d%d", &n, &m) != 2)
    abort ();
  if (n <= 0 || m > MAXE)
    abort ();

  for (i = 0; i < m; i++)
    {
      if (fscanf (fin, "%d%d", &x, &y) != 2)
	abort ();
      if (x <= 0 || y <= 0 || x > n || y > n || x == y)
	abort ();

      if (find (x, y))
	abort ();
    }
  if (fscanf (fin, "%d", &x) == 1)
    abort ();

  return 0;
}

