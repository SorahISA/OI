#!/bin/bash

rm -r data outs

mkdir data
./day2task3-gen

mkdir outs

for n in 1 2 3 4 ; do
  echo $n
  solutions/day2task3-bfdyn < data/calvin.$n > outs/calvin.$n
done

echo 5
solutions/day2task3-period > outs/calvin.5

echo 6
solutions/day2task3-ltor < data/calvin.6 > outs/calvin.6
echo 7
solutions/day2task3-ltor < data/calvin.7 > outs/calvin.7

echo 8
solutions/day2task3-degen < data/calvin.8 > outs/calvin.8
echo 9
solutions/day2task3-degen < data/calvin.9 > outs/calvin.9
echo 10
solutions/day2task3-bipart < data/calvin.10 > outs/calvin.10
