#include <stdio.h>
#include <stdlib.h>

#define MAXN 10000
static int gr[MAXN][MAXN];
static int ns[MAXN][MAXN];
static int deg[MAXN];
static int col[MAXN];

static void
clear_graph (int n)
{
  int i, j;

  for (i = 0; i < n; i++)
    {
      deg[i] = 0;
      for (j = 0; j < n; j++)
	gr[i][j] = 0;
    }
}

static void
print_graph (FILE *f, int n)
{
  int i, j, m = 0;

  for (i = 0; i < n; i++)
    m += deg[i];
  m /= 2;

  fprintf (f, "%d %d\n", n, m);
  for (i = 0; i < n; i++)
    {
      for (j = 0; j < deg[i]; j++)
	if (ns[i][j] > i)
	  fprintf (f, "%d %d\n", i + 1, ns[i][j] + 1);
    }
}

static void
add (int u, int v)
{
  if (u ==v || gr[u][v])
    return;

  gr[u][v] = gr[v][u] = 1;
  ns[u][deg[u]++] = v;
  ns[v][deg[v]++] = u;
}

static void
del1 (int u, int v)
{
  int p;

  for (p = 0; p < deg[u]; p++)
    if (ns[u][p] == v)
      break;

  ns[u][p] = ns[u][--deg[u]];
  gr[u][v] = 0;
}

static void
del (int u, int v)
{
  if (!gr[u][v])
    abort ();

  del1 (u, v);
  del1 (v, u);
}

static void
gen_random (FILE *f, int n)
{
  int u, v;

  clear_graph (n);
  for (u = 0; u < n; u++)
    for (v = 0; v < u; v++)
      if (rand () % 3)
	add (u, v);

  print_graph (f, n);
}

static void
gen_cayley (FILE *f)
{
  int i, n = 99999;

  fprintf (f, "%d %d\n", n, 7 * n);

  for (i = 0; i < n; i++)
    {
      fprintf (f, "%d %d\n", i + 1, (i + 1) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 5) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 7) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 11) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 13) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 17) % n + 1);
      fprintf (f, "%d %d\n", i + 1, (i + 19) % n + 1);
    }
}

static void
add_layer (int act, int vs[])
{
  int i;
  int mid[] = {act, act + 1, act + 2, act + 3};
  int nxt[] = {act + 4, act + 5, act + 6, act + 7};

  for (i = 0; i < 4; i++)
    {
      add (nxt[i], nxt[(i + 1) % 4]);
      add (nxt[i], vs[i]);
      add (mid[i], vs[i]);
      add (mid[i], nxt[i]);
      add (mid[i], vs[(i + 1) % 4]);
      add (mid[i], nxt[(i + 1) % 4]);
    }
  for (i = 0; i < 4; i++)
    vs[i] = nxt[i];
}

static int
gen_speclin (int beg, int rep)
{
  int i, r, act, cvs[4];

  for (i = 0; i < 4; i++)
    {
      add (beg + i, beg + (i + 1) % 4);
      if (i != 3)
	add (beg + i, beg - 1);
      cvs[i] = beg + i;
    }
  act = beg + 4;

  for (r = 0; r < rep; r++)
    {
      add_layer (act, cvs);
      act += 8;

      if (r == rep / 2)
	{
	  add (cvs[0], cvs[2]);
	  add (cvs[1], cvs[3]);
	}
    }
  for (i = 0; i < 3; i++)
    add (cvs[i], act);

  return act;
}

static void
gen_linear (FILE *f, int n, int delta)
{
  int i, j, end;
  int in_randpart[n];

  clear_graph (n);
  for (i = 0; i < n; i++)
    {
      col[i] = rand () % 4;
      in_randpart[i] = 1;
    }

  for (i = 0; i < n; i++)
    if (i % 800 == 300 && i < n - 800)
      {
	end = gen_speclin (i, 50);
	for (j = i; j < end; j++)
	  in_randpart[j] = 0;
      }

  for (i = 0; i < n; i++)
    if (in_randpart[i])
      for (j = 1; j < delta; j++)
	if (i + j < n && in_randpart[i + j] && col[i] != col[i + j] && rand () % 3)
	  add (i, i + j);

  print_graph (f, n);
}

#define MAX_RETRIES 100
#define RETRC 10 

static void
clique (int v, int s)
{
  int i, j;

  for (i = 0; i < s; i++)
    for (j = 0; j < s; j++)
      add (v + i, v + j);
}

static void
gen_random_nreg (FILE *f, int n, int reg, int reme)
{
  int u, v, p0 = reg * n - 1, p1 = 10, p, i;
  int retr;

redo:

  clear_graph (n);

  for (i = 1; i < n - reg; i += 3 * reg)
    clique (i, reg);

  for (retr = 0; retr < MAX_RETRIES; retr++)
    {
      for (u = 0; u < n; u++)
	{
	  if (deg[u] == reg)
	    continue;

	  for (v = u + 1; v < n; v++)
	    {
	      if (deg[v] == reg || gr[u][v])
		continue;

	      if (retr < RETRC)
		p = p0;
	      else if (retr < MAX_RETRIES - 1)
		p = p1;
	      else
		p = 1;

	      if (rand () % p == 0)
		add (u, v);

	      if (deg[u] == reg)
		break;
	    }
	}
      
      for (u = 0; u < n; u++)
	if (deg[u] != reg)
	  break;

      if (u == n)
	break;
    }

  if (retr == MAX_RETRIES)
    goto redo;

  if (reme)
    del (0, ns[0][0]);

  print_graph (f, n);
}

static void
gen_random_bip (FILE *f, int n)
{
  int i, j;

  clear_graph (n);

  for (i = 0; i < n; i++)
    col[i] = rand () % 2;

  for (i = 0; i < n; i++)
    for (j = i + 1; j < n; j++)
      if (col[i] != col[j] && rand () % 5)
	add (i, j);

  print_graph (f, n);
}

int main (void)
{
  FILE *f;

  srand(1);
  f = fopen ("data/calvin.1", "w");
  gen_random (f, 7);
  fclose (f);

  srand(2);
  f = fopen ("data/calvin.2", "w");
  gen_random (f, 14);
  fclose (f);

  srand(3);
  f = fopen ("data/calvin.3", "w");
  gen_random (f, 21);
  fclose (f);

  srand(4);
  f = fopen ("data/calvin.4", "w");
  gen_random (f, 28);
  fclose (f);

  f = fopen ("data/calvin.5", "w");
  gen_cayley (f);
  fclose (f);

  srand (5);
  f = fopen ("data/calvin.6", "w");
  gen_linear (f, 10000, 7);
  fclose (f);

  srand (6);
  f = fopen ("data/calvin.7", "w");
  gen_linear (f, 10000, 9);
  fclose (f);

  srand (7);
  f = fopen ("data/calvin.8", "w");
  gen_random_nreg (f, 10000, 4, 1);
  fclose (f);

  srand (8);
  f = fopen ("data/calvin.9", "w");
  gen_random_nreg (f, 10000, 4, 0);
  fclose (f);

  srand (9);
  f = fopen ("data/calvin.10", "w");
  gen_random_bip (f, 10000);
  fclose (f);

  return 0;
}
