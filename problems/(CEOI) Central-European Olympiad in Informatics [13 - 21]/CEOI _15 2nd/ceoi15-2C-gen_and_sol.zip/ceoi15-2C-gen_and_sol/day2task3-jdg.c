#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define BUG(...) do { fprintf(stderr, "Internal error: " __VA_ARGS__); exit(1); } while (0)
#define WRONG(...) do { fprintf(stderr, "Wrong answer\n"); puts("0"); exit(0); } while (0)
#define OKAY(...) do { fprintf(stderr, "Correct\n"); puts("1"); exit(0); } while (0)

#define MAXN 1000000
#define BLEN 10000000

static char buf[BLEN + 1];

static int n, m;

static int color[MAXN];

typedef enum {RN, END, ERR} rv;

static rv
get_int (char **pos, int *val)
{
  char *p = *pos, *q;

  while (isspace (*p))
    p++;

  if (!*p)
    return END;

  if (!isdigit (*p))
    return ERR;

  for (q = p; isdigit (*q); q++)
    continue;

  if (*q && !isspace (*q))
    return ERR;

  if (q - p > 7)
    return ERR;

  *q = 0;
  *val = atoi (p);
  *pos = q + 1;

  return RN;
}

int main (int argc, char *argv[])
{
  int i, x, y, nc, cor_nc, c, t;

  if (argc != 4)
    {
      fprintf(stderr, "Usage: %s <input> <correct-output> <checked-output>\n", argv[0]);
      return 1;
    }
  FILE *fin = fopen (argv[1], "r");
  FILE *cor = fopen (argv[2], "r");
  FILE *check = fopen (argv[3], "r");

  fscanf (cor, "%d", &cor_nc);

  fscanf (fin, "%d%d", &n, &m);

  if (!fgets(buf, BLEN, check) || sscanf (buf, "%d", &nc) != 1)
    WRONG("No data\n");
  if (nc != cor_nc)
    WRONG("Wrong number of colors\n");

  t = 0;
  for (c = 1; c <= nc; c++)
    {
      char *p;

      if (!fgets(buf, BLEN, check))
	WRONG("Too few lines on input\n");

      p = buf;

      while (1)
	{
	  rv st = get_int (&p, &x);

	  if (st == ERR)
	    WRONG("Malformed number\n");
	  if (st == END)
	    break;

	  if (x <= 0 || x > n)
	    WRONG("Wrong vertex number\n");
	  x--;
	  if (color[x])
	    WRONG("Twice colored vertex\n");

	  color[x] = c;
	  t++;
	}
    }

  if (t != n)
    WRONG("Some uncolored vertices\n");

  for (i = 0; i < m; i++)
    {
      fscanf (fin, "%d%d", &x, &y);

      if (color[x - 1] == color[y - 1])
	WRONG("Adjacent vertices with the same color\n");
    }

  OKAY();
}
