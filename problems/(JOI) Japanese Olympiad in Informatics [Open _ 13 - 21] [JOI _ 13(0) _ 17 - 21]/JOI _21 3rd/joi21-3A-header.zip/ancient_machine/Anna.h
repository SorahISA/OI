#include <vector>

void Anna(int N, std::vector<char> S);

void Send(int a);
