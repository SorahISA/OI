#include "Bruno.h"
#include <vector>

namespace {

int variable_example = 0;

int FunctionExample(int P) { return 1 - P; }

}  // namespace

void Bruno(int N, int L, std::vector<int> A) {
  for (int i = 0; i < L; i++) {
    variable_example += FunctionExample(A[i]);
  }
  for (int i = 0; i < N; i++) {
    Remove(i);
  }
}
