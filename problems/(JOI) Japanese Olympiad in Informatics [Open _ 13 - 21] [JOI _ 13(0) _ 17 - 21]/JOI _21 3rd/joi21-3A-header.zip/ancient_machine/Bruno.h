#include <vector>

void Bruno(int N, int L, std::vector<int> A);

void Remove(int d);
