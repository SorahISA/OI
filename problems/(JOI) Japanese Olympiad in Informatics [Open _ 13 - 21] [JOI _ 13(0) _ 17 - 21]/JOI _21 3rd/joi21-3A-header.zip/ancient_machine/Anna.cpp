#include "Anna.h"
#include <vector>

namespace {

int variable_example = 0;

}

void Anna(int N, std::vector<char> S) {
  variable_example++;
  Send(0);
  Send(1);
}
