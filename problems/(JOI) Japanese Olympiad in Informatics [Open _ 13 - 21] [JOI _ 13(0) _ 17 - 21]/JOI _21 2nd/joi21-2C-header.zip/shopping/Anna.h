void InitA(int N, int L, int R);
void ReceiveA(bool x);
int Answer();

void SendA(bool y);
