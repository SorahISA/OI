#include <vector>

void InitB(int N, std::vector<int> P);
void ReceiveB(bool y);

void SendB(bool x);
