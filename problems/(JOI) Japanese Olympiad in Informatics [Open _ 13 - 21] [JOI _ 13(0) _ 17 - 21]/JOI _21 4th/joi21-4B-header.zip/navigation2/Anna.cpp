#include "Anna.h"
#include <vector>

namespace {

int FunctionExample(int r, int c, int K) {
  return (r + c) % K + 1;
}

} // namespace

void Anna(int N, int K, std::vector<int> R, std::vector<int> C) {
  for (int r = 0; r < N; r++) {
    for (int c = 0; c < N; c++) {
      SetFlag(r, c, FunctionExample(r, c, K));
    }
  }
}
