#include "Bruno.h"
#include <vector>

namespace {

int variable_example = 1;

} // namespace

std::vector<int> Bruno(int K, std::vector<int> value) {
  variable_example += 1;
  std::vector<int> res(K, 0);
  for (int i = 0; i < K; i++) {
    res[i] = (value[i] % 5);
  }
  return res;
}
