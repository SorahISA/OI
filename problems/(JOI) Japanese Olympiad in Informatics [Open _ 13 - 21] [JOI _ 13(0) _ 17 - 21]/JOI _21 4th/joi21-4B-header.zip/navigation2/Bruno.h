#include <vector>

std::vector<int> Bruno(int K, std::vector<int> value);
