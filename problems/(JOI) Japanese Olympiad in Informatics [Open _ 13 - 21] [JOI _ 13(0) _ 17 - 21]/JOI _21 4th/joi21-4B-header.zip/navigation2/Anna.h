#include <vector>

void Anna(int N, int K, std::vector<int> R, std::vector<int> C);
void SetFlag(int r, int c, int value);
